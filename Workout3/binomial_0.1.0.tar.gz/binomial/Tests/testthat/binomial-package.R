#' @import ggplot2
#' @docType package
#' @name binomial
NULL
